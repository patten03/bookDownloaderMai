import requests
from bs4 import BeautifulSoup
from pathlib import Path

headers = {
    'authority': 'www.nytimes.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'en-US,en;q=0.9,ru;q=0.8',
    'cache-control': 'max-age=0',
    'dnt': '1',
    'if-modified-since': 'Mon, 28 Nov 2022 00:06:21 GMT',
    'sec-ch-ua': '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'sec-gpc': '1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac macOS 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
}

# try my luck with this book http://elibrary.mai.ru/MegaPro/Download/ToView/57112?idb=NewMAI2014
url = "http://elibrary.mai.ru/MegaPro/Download/ToView/71259?idb=NewMAI2014"
response = requests.get(url, headers=headers, timeout=9000, allow_redirects=True)
doc = response.text

soup = BeautifulSoup(doc, 'html.parser')

# getting reference to first image
firstImage = soup.find('img', id="pgimg")
firstImage = firstImage['src']

# getting count of pages
pageCount = soup.find("span", id="bmkpagetotalnum")
pageCount = int(pageCount.text)

# get url to first image 
domain = response.url.split('/')
domain = domain[0] + "//" + domain[2]
print(domain + firstImage)

# make folder
folder = "book"
Path("./" + folder).mkdir(parents = True, exist_ok = True)

# loop to download all images
for i in range(1, pageCount + 1):
    curImage = firstImage.replace("00001", str(i).zfill(5))
    response = requests.get(domain + curImage)
    with open("./" + folder +"/" + str(i).zfill(5) + ".png", 'wb') as file:
        file.write(response.content)

def firstEnter(s: requests.Session) -> BeautifulSoup:
    

def getPageCount(soup: BeautifulSoup) -> int:
    pageCount = soup.find("span", id="bmkpagetotalnum")
    pageCount = int(pageCount.text)

    return pageCount

def getRefToPageImage(soup: BeautifulSoup, domain: str) -> str:
    imageSubRef = soup.find('img', id="pgimg")
    imageSubRef = imageSubRef['src']

    return domain + imageSubRef